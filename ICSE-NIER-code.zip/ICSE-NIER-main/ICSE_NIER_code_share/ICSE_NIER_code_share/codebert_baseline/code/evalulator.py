import csv
import sys
import numpy as np
from collections import Counter
import logging
from sklearn.metrics import fbeta_score, f1_score, precision_recall_fscore_support, accuracy_score, matthews_corrcoef, classification_report

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# increase the field size limit
csv.field_size_limit(sys.maxsize)


def accuracy(preds, labels):
    correct = sum(int(pred == label) for pred, label in zip(preds, labels))
    total = len(labels)
    accuracy = correct / total
    return accuracy


def precision(preds, labels):
    true_positives = sum(int(pred == 1 and label == 1) for pred, label in zip(preds, labels))
    false_positives = sum(int(pred == 1 and label == 0) for pred, label in zip(preds, labels))
    precision = true_positives / (true_positives + false_positives)
    return precision


def recall(preds, labels):
    true_positives = sum(int(pred == 1 and label == 1) for pred, label in zip(preds, labels))
    false_negatives = sum(int(pred == 0 and label == 1) for pred, label in zip(preds, labels))
    recall = true_positives / (true_positives + false_negatives)
    return recall


def evaluator(preds, labels, raw_pred_scores=None):

    pos_correct_count, neg_correct_count = 0,0
    for i in range(len(preds)):
        if preds[i] == labels[i]:
            if labels[i] == 1:
                pos_correct_count +=1
            elif labels[i] == 0:
                neg_correct_count +=1

    print('accuracy: ', round(accuracy(preds, labels), 4))
    print('precision: ', round(precision(preds, labels), 4))
    print('recall: ', round(recall(preds, labels), 4))
    print('F0.5: ', fbeta_score(labels, preds, average=None, beta=0.5)[1])
    print('F1: ', f1_score(labels, preds))


def print_results(data):
    
    preds = []
    labels = []
    raw_pred_scores = []
    for key in data:
        result = data[key][0]
        preds.append(int(result['prediction']))
        labels.append(int(result['target']))
        raw_pred_scores.append(float(result['score']))
    print(labels)
 
    print("*" * 50)
    print(Counter(preds))
    print('label:', Counter(labels))
    evaluator(preds, labels, raw_pred_scores=raw_pred_scores)
    print("*" * 50)
    print('Results on Half of data:')
    half_preds = preds[0:92]+preds[184:276]
    half_labels = labels[0:92]+labels[184:276]
    print(Counter(half_labels))
    evaluator(half_preds, half_labels)


def read_preds(path_):
    data = {}
    seed = '0'
    with open(path_) as f:
        lines = f.readlines()
        for row in lines:
            
            row = row.split()
            index, prediction, score, target = row[0], row[1], row[2], row[3]
            try:
                data[index].append({"prediction": prediction, "target": target, "seed": seed, "index":index, "score":score})
            except KeyError:
                data[index] = [{"prediction": prediction, "target": target, "seed": seed, "index":index, "score":score}]

    print_results(data)
    return data
read_preds('saved_cwe_codebert_seed1234/predictions.txt')
