CUDA_VISIBLE_DEVICES=1 python run.py     --output_dir=./saved_cwe_codebert_seed1234     --model_type=roberta     --tokenizer_name=microsoft/codebert-base     --model_name_or_path=microsoft/codebert-base  \
     	--do_train \
	--do_eval \
	--train_data_file=../../dataset/train_for_codexglue_binary.json   \
       	--eval_data_file=../../dataset/validation_for_codexglue_binary.json  \
	--test_data_file=../../dataset/validation_for_codexglue_binary.json  \
	--epoch 5 --block_size 512  \
       	--train_batch_size 8     --eval_batch_size 8     --learning_rate 5e-5    --evaluate_during_training   \
      	--seed 1234 
