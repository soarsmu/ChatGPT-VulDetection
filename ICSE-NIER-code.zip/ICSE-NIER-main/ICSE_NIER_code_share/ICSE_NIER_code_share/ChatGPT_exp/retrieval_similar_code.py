"""
This is a simple application for sentence embeddings: semantic search

We have a corpus with various sentences. Then, for a given query sentence,
we want to find the most similar sentence in this corpus.

This script outputs for various queries the top 5 most similar sentences in the corpus.
"""
from sentence_transformers import SentenceTransformer, util
import torch, json, pickle


test_file_ = '../dataset/test_for_codexglue_binary.json'
test_data = []
with open(test_file_, 'r') as f:
     data = f.readlines()
     for l in data:
         l = json.loads(l)
         test_data.append(l)
print(len(test_data))
print(test_data[1])
test_functions = [l['func'] for l in test_data]


train_file_ = '../dataset/train_for_codexglue_binary.json'
train_data = []
with open(train_file_, 'r') as f:
    data = f.readlines()
    for l in data:
        l = json.loads(l)
        train_data.append(l)

vulnerable_functions, clean_functions = [],[]
for l in train_data:
    if int(l['target']) == 1:
        vulnerable_functions.append(l['func'])
    else:
        clean_functions.append(l['func'])



embedder = SentenceTransformer('microsoft/codebert-base')


corpus = clean_functions + vulnerable_functions
corpus_labels = ['0']*len(clean_functions) +  ['1']*len(vulnerable_functions)


corpus_embeddings = embedder.encode(corpus, convert_to_tensor=True)

# Query sentences:
queries = test_functions




# Find the closest 5 sentences of the corpus for each query sentence based on cosine similarity
retrieval_results = []
top_k = min(10, len(corpus))
for query in queries:
    query_embedding = embedder.encode(query, convert_to_tensor=True)

    # We use cosine-similarity and torch.topk to find the highest 5 scores
    cos_scores = util.cos_sim(query_embedding, corpus_embeddings)[0]
    top_results = torch.topk(cos_scores, k=top_k)
    """
    print("\n\n======================\n\n")
    print("Query:", query[0:2000])
    print("\nTop 5 most similar sentences in corpus:")
    """
    retrieval_ = []
    for score, idx in zip(top_results[0], top_results[1]):
        print(corpus[idx][0:2000], "(Score: {:.4f})".format(score))
        retrieval_.append( (corpus[idx], corpus_labels[idx]) )
    retrieval_results.append(retrieval_)

print(len(retrieval_results))
print(retrieval_results[0])


with open('retrieval_pos_neg.pkl', 'wb') as fw:
    pickle.dump(retrieval_results, fw)

