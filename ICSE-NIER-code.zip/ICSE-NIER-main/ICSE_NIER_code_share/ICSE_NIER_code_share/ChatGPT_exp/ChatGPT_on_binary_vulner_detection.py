import os
import openai
import json
import time


import os
import csv
import sys
import numpy as np
from collections import Counter
import logging
from sklearn.metrics import f1_score, precision_recall_fscore_support, accuracy_score, matthews_corrcoef, classification_report
import pickle


def accuracy(preds, labels):
    correct = sum(int(pred == label) for pred, label in zip(preds, labels))
    total = len(labels)
    accuracy = correct / total
    return accuracy


def precision(preds, labels):
    true_positives = sum(int(pred == 1 and label == 1) for pred, label in zip(preds, labels))
    false_positives = sum(int(pred == 1 and label == 0) for pred, label in zip(preds, labels))
    precision = true_positives / (true_positives + false_positives)
    return precision


def recall(preds, labels):
    true_positives = sum(int(pred == 1 and label == 1) for pred, label in zip(preds, labels))
    false_negatives = sum(int(pred == 0 and label == 1) for pred, label in zip(preds, labels))
    recall = true_positives / (true_positives + false_negatives)
    return recall


def evaluator(preds, labels):

    pos_correct_count, neg_correct_count = 0,0
    for i in range(len(preds)):
        if preds[i] == labels[i]:
            if labels[i] == 1:
                pos_correct_count +=1
            elif labels[i] == 0:
                neg_correct_count +=1
    print('correct for 1 class:', pos_correct_count)
    print('correct for 0 class:', neg_correct_count)

    print('accuracy: ', round(accuracy(preds, labels), 4))
    print('precision: ', round(precision(preds, labels), 4))
    print('recall: ', round(recall(preds, labels), 4))
    print('F1: ', f1_score(labels, preds))

def remove_spaces(string_):
    return ' '.join(string_.split())

"""
Read Data
"""
test_file_ = '../dataset/test_for_codexglue_binary.json'


test_data = []
with open(test_file_, 'r') as f:
     data = f.readlines()
     for l in data:
         l = json.loads(l)
         test_data.append(l)
print(len(test_data))
print(test_data[1])



train_file_ = '../dataset/train_for_codexglue_binary.json'
train_data = []
with open(train_file_, 'r') as f:
    data = f.readlines()
    for l in data:
        l = json.loads(l)
        train_data.append(l)
vulnerable_functions, clean_functions = [],[]
for l in train_data:
    if int(l['target']) == 1:
        vulnerable_functions.append(remove_spaces(l['func']))
    else:
        clean_functions.append(remove_spaces(l['func']))




"""
Buildup Prompts
"""
def prompt_designs(test_data_sample, idx, option='basic', topk=1):
    input_ = test_data_sample['func']
    input_ = remove_spaces(input_)
    input_ = input_[0:1000]

    if option == 'basic':
        P = "Now you need to identify whether a method contains any potential vulnerability or not. If has any potential vulnerability, output: 'this code is vulnerable'. Otherwise, output: 'this code is non-vulnerable'. You only to give the prior two answers. The Code is: \n " + input_ + "\n Let's Start: "
    
    elif option == 'A1':
        P = "You are an experienced developer who knows the security vulnerability very well. Now you need to identify whether a method contains any potential vulnerability or not. If has any potential vulnerability, output: 'this code is vulnerable'. Otherwise, output: 'this code is non-vulnerable'. You only to give the prior two answers. The Code is: \n " + input_ + "\n Let's Start: "
    
    elif option == 'A2':
         P = "Now you need to identify whether a method contains any potential vulnerability or not. If has any potential vulnerability, output: 'this code is vulnerable'. Otherwise, output: 'this code is non-vulnerable'. You only to give the prior two answers. The Code is: \n " + input_ + " Its from project " + test_data_sample['project'] + "\n Let's Start: "
    
    elif option == 'A3':

         opening = 'Before you start to judge, here are some most dangerous CWE types with examples and explanations. You can learn from them to know what code is more likely to be vulnerable.'
         ## Out-of-bounds Write.
         type1 = "The Code is: int returnChunkSize(void *) { /* if chunk info is valid, return the size of usable memory, * else, return -1 to indicate an error */ ... } int main() { ... memcpy(destBuf, srcBuf, (returnChunkSize(destBuf)-1)); ... } \n Let's Start: this code is vulnerable."
         ## Improper Neutralization of Input During Web Page Generation ('Cross-site Scripting') 
         type2 = "The Code is: $username = $_GET['username']; echo '<div class='header'> Welcome, ' . $username . '</div>'; \n Let's Start: this code is vulnerable."
         ## Improper Neutralization of Special Elements used in an SQL Command ('SQL Injection') 
         type3 = "The Code is: ... string userName = ctx.getAuthenticatedUserName(); string query = 'SELECT * FROM items WHERE owner = ' + userName + ' AND itemname = ' + ItemName.Text + '''; sda = new SqlDataAdapter(query, conn); DataTable dt = new DataTable(); sda.Fill(dt); ... \n Let's Start: this code is vulnerable."
         ## Improper Input Validation.
         type4 = "The Code is:  #define MAX_DIM 100 ... /* board dimensions */  int m,n, error; board_square_t *board; printf('Please specify the board height: \n'); error = scanf('%d', &m); if ( EOF == error ){ die('No integer passed: Die evil hacker!\n');} printf('Please specify the board width: \n'); error = scanf('%d', &n); if ( EOF == error ){ die('No integer passed: Die evil hacker!\n'); } if ( m > MAX_DIM || n > MAX_DIM ) {die('Value too large: Die evil hacker!\n');} board = (board_square_t*) malloc( m * n * sizeof(board_square_t)); ...\n Let's Start: this code is vulnerable."
         ##  Out-of-bounds Read
         type5 = "The Code is: .. // check that the array index is within the correct // range of values for the array if (index >= 0 && index < len) { ... \n Let's Start: this code is vulnerable."
         ## Improper Neutralization of Special Elements used in an OS Command ('OS Command Injection')
         type6 = "The Code is: int main(int argc, char** argv) \n { char cmd[CMD_MAX] = '/usr/bin/cat '; \nstrcat(cmd, argv[1]);\n system(cmd); } \n Let's Start: this code is vulnerable."
         ## Use After Free
         type7 = "The Code is: char* ptr = (char*)malloc (SIZE);\n if (err) { abrt = 1;\n free(ptr);\n } ... if (abrt) { logError('operation aborted before commit', ptr);} \n Let's Start: this code is vulnerable."
         ## Improper Limitation of a Pathname to a Restricted Directory ('Path Traversal')
         type8 = "The Code is: String filename = System.getProperty('com.domain.application.dictionaryFile'); File dictionaryFile = new File(filename); \n Let's Start: this code is vulnerable."
         ## Cross-Site Request Forgery (CSRF)
         ## NULL Pointer Dereference
         type9 = "The Code is: void host_lookup(char *user_supplied_addr){ struct hostent *hp; in_addr_t *addr; char hostname[64]; in_addr_t inet_addr(const char *cp); /*routine that ensures user_supplied_addr is in the right format for conversion */ validate_addr_form(user_supplied_addr); addr = inet_addr(user_supplied_addr); hp = gethostbyaddr( addr, sizeof(struct in_addr), AF_INET); strcpy(hostname, hp->h_name); } Let's Start: this code is vulnerable."
         ## Integer Overflow or Wraparound
         type10 = "The Code is: nresp = packet_get_int(); if (nresp > 0) { response = xmalloc(nresp*sizeof(char*)); for (i = 0; i < nresp; i++) response[i] = packet_get_string(NULL);} \n Let's Start: this code is vulnerable."
         ## Use of Hard-coded Credentials
         type11 = "The Code is: int VerifyAdmin(char *password) { if (strcmp(password, 'Mew!')) { printf('Incorrect Password!\n'); return(0) } printf('Entering Diagnostic Mode...\n'); return(1);} \n Let's Start: this code is vulnerable."
         ## Improper Neutralization of Special Elements used in a Command ('Command Injection')
         type12 = "The Code is: int main(int argc, char** argv) { char cmd[CMD_MAX] = '/usr/bin/cat '; strcat(cmd, argv[1]); system(cmd);} \n Let's Start: this code is vulnerable."
         ##Improper Restriction of Operations within the Bounds of a Memory Buffer
         type13 = "The Code is: int main (int argc, char **argv) { char *items[] = {'boat', 'car', 'truck', 'train'}; int index = GetUntrustedOffset(); printf('You selected %s\n', items[index-1]); } \n Let's Start: this code is vulnerable."
         ## Concurrent Execution using Shared Resource with Improper Synchronization ('Race Condition')
         type14 = "The Code is: void f(pthread_mutex_t *mutex) { pthread_mutex_lock(mutex);  /* access shared resource */ pthread_mutex_unlock(mutex);} \n Let's Start: this code is vulnerable."
         ## Uncontrolled Resource Consumption
         type15 = "The Code is: sock=socket(AF_INET, SOCK_STREAM, 0); while (1) { newsock=accept(sock, ...); printf('A connection has been accepted\n'); pid = fork();} \n Let's Start: this code is vulnerable."
         #type16 = "The Code is: \n Let's Start: this code is vulnerable."

         P = "You need to identify whether a method contains any potential vulnerability or not. If has any potential vulnerability, output: 'this code is vulnerable'. Otherwise, output: 'this code is non-vulnerable'. You only to give the prior two answers."
         #P += opening
         for type_ in [type1, type2, type3, type4, type5, type6, type7, type8, type9, type10, type11, type12, type13, type14, type15]:
            P += type_
         P = P + "The Code you is: " + input_ + "\n Let's Start: "
    
    elif  option == 'A4':
         P = "Now you need to identify whether a method contains any potential vulnerability or not. If has vulnerability, output: 'this code is vulnerable'. Otherwise, output: 'this code is non-vulnerable'. You only to give the prior two answers."
         if topk>1:
            P = P + "The Code is: \n " + clean_functions[0] + "\n Let's Start: this code is non-vulnerable."
         for ijj in range(10, 10+max(topk-1, 1)):
             P = P + "The Code is: \n " + vulnerable_functions[ijj] + "\n Let's Start: this code is vulnerable. "
         P = P + "The Code is: \n " + input_ + "\n Let's Start: " 
    
    elif option == 'A5':
    
        P = "Now you need to identify whether a method contains any potential vulnerability or not. If has vulnerability, output: 'this code is vulnerable'. Otherwise, output: 'this code is non-vulnerable'. You only to give the prior two answers."
        with open('retrieval_pos_neg.pkl', 'rb') as f:
            retrieval_methods = pickle.load(f)
    
        retrieval_method = retrieval_methods[idx]
        for retrieval_ in retrieval_method[0:topk]:
             print (retrieval_[1])
             if int(retrieval_[1]) == 0 : 
                #P = P + "The Code is: " + remove_spaces(retrieval_[0])[0:1000] + "\n Let's Start: this code is non-vulnerable. "
                P = P + "The Code is: " + remove_spaces(retrieval_[0])[0:2000] + "\n Let's Start: this code is non-vulnerable. " 
             else:
                #P = P + "The Code is: " + remove_spaces(retrieval_[0])[0:1000] + "\n Let's Start: this code is vulnerable. "
                P = P + "The Code is: " + remove_spaces(retrieval_[0])[0:2000] + "\n Let's Start: this code is vulnerable. "
        P = P + "The Code is: \n " + input_ + "\n Let's Start: "




    #print(P)
    #P = P[max(0, len(P)-10000):]
    return P



"""
Call ChatGPT
"""
key = '' ## Your KEY here
openai.api_key = key
Model = openai.ChatCompletion()

def call_chatgpt(P, idx):
    
    completion= None
    while completion is None:
        try:
            completion = Model.create(model="gpt-3.5-turbo",
            #completion =Model.create(model="gpt-4",
                                            messages=[
                                                                {"role": "user", "content": P},
                                                                ],
                                            temperature=0.5,
                                            max_tokens=80,
                    )
            
        except Exception as exc:
            print(exc)
            print('Failed on %s...' % idx)
            time.sleep(10)
            continue

        print(P)


    print(completion.choices[0]['message']['content'])
    return completion.choices[0]['message']['content']





top_k = 5
#option = 'A3'
option = 'A5'
model = 'gpt3dot5'
#f_save = open('generated_results/'+ model + '_' + option + '_' + str(top_k) + '.txt','w') 

for i in range(239, 260):
#for i in range(90, 93):
#for i in range(len(test_data)):
  
    P = prompt_designs(test_data[i], i, option, top_k)
    #response = call_chatgpt(P, i)
    print(i)  
    print(P)
    print('target:', test_data[i]['target'])
    print('-'*20)
    
    #f_save.write(str(i) + ':\t' + str(test_data[i]['target']) + '\t' + response.strip().replace('\n', 't') + '\n')






