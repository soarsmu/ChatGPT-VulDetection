

1. run ChatGPT:  python ChatGPT_on_binary_vulner_detection.py

Please change the parameters at Line 220-222 to choose different promtps

For A5, you need to run 'python retrieval_similar_code.py' 

2. run ChatGPT Plus, as we do not have the API access, we run it on the ChatGPT Plus Application https://chat.openai.com/.
You can use ChatGPT_on_binary_vulner_detection.py to get the prompt (and the input code) and paste it on the ChatGPT Plus Application to get the results

