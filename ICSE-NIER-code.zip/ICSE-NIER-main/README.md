# ICSE-NIER

Please download and unzip the files to check the codes.

For baseline, please go into the folder 'codebert_baseline' and run the training/testing scripts there;

For ChatGPT, please go into the folder 'ChatGPT_exp' and recheck README there to know how to use the code.
